/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package observercafeteria;

import Observer.Barista;
import Observer.ConcreteBarista;
import Subject.ConcreteCooperativaCafes;
import Subject.CooperativaCafe;

/**
 *
 * @author estudiantes
 */
public class TiendaCafe  {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ConcreteCooperativaCafes cooperativa= new ConcreteCooperativaCafes();
       Barista barista1= new ConcreteBarista("Jhon",111);
       Barista barista2= new ConcreteBarista("Jhon",112);
       
       cooperativa.suscribir(barista1);
       cooperativa.suscribir(barista2);
       
       cooperativa.registrarLote("Bourbon rosado", "Cacao", "Huila", 1200, "Don pepe", 20);
    }
    
}
