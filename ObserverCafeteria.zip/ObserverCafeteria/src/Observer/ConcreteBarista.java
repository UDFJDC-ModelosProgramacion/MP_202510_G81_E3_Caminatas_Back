/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Observer;

/**
 *
 * @author estudiantes
 */
public class ConcreteBarista implements Barista {

    private final String name;
    private final int id;
    
    public ConcreteBarista(String name, int id){
    this.id = id;
    this.name = name;
    
    }

    @Override
    public void update(String varietale, String notes, String origin, int height, String producer, int amount) {
        System.out.println(" Mensaje para " + name + ", id: " + id + " ¡Nuevo lote!");
        System.out.println(" Varietal: " + varietale +", notas: " + notes + ", origen: "+ origin + ", altura de cultivo: "+height+", productor: " + producer+ ", cantidad: "+ amount);
    }
}
