/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Subject;

import Observer.Barista;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author estudiantes
 */
public class ConcreteCooperativaCafes implements CooperativaCafe {
    private List<Barista> baristas = new ArrayList<> ();
    
    @Override
    public void suscribir(Barista barista) {
        baristas.add(barista);
    }

    @Override
    public void desuscribir(Barista barista) {
        baristas.remove(barista);
    }

    @Override
    public void notificar(String varietale, String notes, String origin, int height, String producer, int amount) {
        for( Barista barista: baristas){
            barista.update(varietale, notes, origin, height, producer, amount);
        }
    }

    public void registrarLote(String varietale, String notes, String origin, int height, String producer, int amount) {
        System.out.println("Nuevo lote registrado, Varietal: " + varietale +", notas: " + notes + ", origen: "+ origin + ", altura de cultivo: "+height+", productor: " + producer+ ", cantidad: "+ amount);
        notificar(varietale, notes, origin, height, producer,amount);
    }
    
}
