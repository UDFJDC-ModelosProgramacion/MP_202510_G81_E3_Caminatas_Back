/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Subject;

import Observer.Barista;

/**
 *
 * @author estudiantes
 */
public interface CooperativaCafe {
    void suscribir(Barista barista);
    void desuscribir(Barista barista);
    void notificar(String varietale, String notes, String origin, int height, String producer, int amount);
}
