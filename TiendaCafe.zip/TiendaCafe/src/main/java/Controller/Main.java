/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Barista;
import Model.CooperativaCafe;
import Model.LoteCafe;

/**
 *
 * @author estudiantes
 */
public class Main {
    public static void main(String[] args) {
        CooperativaCafe cooperativa = new CooperativaCafe();

        Barista barista1 = new Barista("Carlos",10101111);
        Barista barista2 = new Barista("Ana",10101001);

        cooperativa.agregarObserver(barista1);
        cooperativa.agregarObserver(barista2);

        LoteCafe lote = new LoteCafe("JuanValdez", "Finca La Vaca", 30);
        cooperativa.registrarLote(lote);
    }
    
}
