/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author estudiantes
 */
public class LoteCafe {
    private String variedad;
    private String productor;
    private int cantidadLibras;

    public LoteCafe(String variedad, String productor, int cantidadLibras) {
        this.variedad = variedad;
        this.productor = productor;
        this.cantidadLibras = cantidadLibras;
    }

    public String getVariedad() { return variedad; }
    public String getProductor() { return productor; }
    public int getCantidadLibras() { return cantidadLibras; }
    
}
