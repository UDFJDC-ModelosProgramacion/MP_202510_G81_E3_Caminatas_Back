/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author estudiantes
 */
public class Barista implements Observer{
    private String nombre;
    private int identificacion;

    public Barista(String nombre, int identificacion) {
        this.nombre = nombre;
        this.identificacion= identificacion;
    }

    @Override
    public void actualizar(String mensaje) {
        System.out.println("Barista " + nombre + " con "+ identificacion +" recibió la notificación: \n" + mensaje);
    }
    
}
