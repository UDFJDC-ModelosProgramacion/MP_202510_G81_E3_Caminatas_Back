/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Model;

/**
 *
 * @author estudiantes
 */
public interface Subject {
    
    void agregarObserver(Observer o);
    void eliminarObserver(Observer o);
    void notificarObservers(String mensaje);
    
}
