/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author estudiantes
 */
public class CooperativaCafe implements Subject{
     private List<Observer> baristas = new ArrayList<>();

    @Override
    public void agregarObserver(Observer o) {
        baristas.add(o);
    }

    @Override
    public void eliminarObserver(Observer o) {
        baristas.remove(o);
    }

    @Override
    public void notificarObservers(String mensaje) {
        for (Observer barista : baristas) {
            barista.actualizar(mensaje);
        }
    }

    public void registrarLote(LoteCafe lote) {
        String mensaje = "--Nuevo lote disponible: " + lote.getVariedad() +
                         " de " + lote.getProductor() + 
                         " (" + lote.getCantidadLibras() + " libras)";
        notificarObservers(mensaje);
    }
    
    
}
